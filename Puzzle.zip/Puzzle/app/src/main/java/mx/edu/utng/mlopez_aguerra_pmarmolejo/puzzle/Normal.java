package mx.edu.utng.mlopez_aguerra_pmarmolejo.puzzle;


public class Normal implements Estrategia{
    protected int[] tablero;
    private int disponible;

    public Normal(){
        tablero= new int[16];
        for(int i=0;i<16;i++){
            tablero[i]=i;
        }
        disponible= 15;
    }

    public void moverPieza(int pos1, int pos2) {
        int tempo;
        if(verificarMov(pos1)){
            tempo=tablero[pos1];
            tablero[pos1]=tablero[disponible];
            tablero[disponible]=tempo;
            disponible=pos1;
        }
    }

    public boolean verificarMov(int pos) {
        if((pos/4==disponible/4&& Math.abs(pos-disponible)==1)||
                (pos%4==disponible%4 &&Math.abs(pos-disponible)==4)){
            return true;
        }else {
            return false;
        }
    }


    public boolean yaGano() {
        for(int i=0; i<16;i++){
            if(tablero[i]!=i){
                return false;
            }
        }
        return true;
    }

    public int getDisponible() {
        return disponible;
    }
}
