package mx.edu.utng.mlopez_aguerra_pmarmolejo.puzzle;

public class Libre {
    protected int[] tablero;
    private int disponible;

    public Libre(){
        tablero= new int[16];
        for(int i=0;i<16;i++){
            tablero[i]=i;
        }
        disponible= 15;
    }


    public void moverPieza(int pos1, int pos2) {
        int tempo;
        tempo=tablero[pos1];
        tablero[pos1]=tablero[pos2];
        tablero[pos2]=tempo;
    }


    public boolean verificarMov(int pos) {
        return true;
    }


    public boolean yaGano() {
        for(int i=0; i<16;i++){
            if(tablero[i]!=i){
                return false;
            }
        }
        return true;
    }

    public int getDisponible() {
        return disponible;
    }
}
