package mx.edu.utng.mlopez_aguerra_pmarmolejo.puzzle;

public interface Estrategia {
    public void moverPieza(int pos1,int pos2);
    public boolean verificarMov(int pos);
    public boolean yaGano();
}
