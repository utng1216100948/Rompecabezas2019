package mx.edu.utng.mlopez_aguerra_pmarmolejo.puzzle;

import android.os.SystemClock;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.Chronometer;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;

public class MainActivity extends AppCompatActivity implements View.OnTouchListener,AdapterView.OnItemSelectedListener {


    private Button btnMezclar;
    private Button btnSalir;
    private Spinner cmbTipo;
    private Spinner cmbOpciones;
    private int tipo;
    private int img;
    private Estrategia juego;
    private ImageButton[] imagenes;
    private int dispo=15;
    private int pos1;
    private int pos2;
    private boolean banPar=true;
    private int x1;
    private int y1;
    private int x2;
    private int y2;
    private int dxy;
    public int contador;
    public TextView txtContador;
    public TextView txtTime;

    Chronometer chronometro;
    Boolean correr=false;
    long detenerse;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtContador = findViewById(R.id.txt_contador);
        txtTime = findViewById(R.id.chronometro);

        inicializarControles();

        cmbTipo.setOnItemSelectedListener(this);
        cmbOpciones.setOnItemSelectedListener(this);

        for(int i=0;i<16;i++){
            imagenes[i].setOnTouchListener(this);
        }

        btnMezclar.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                mezclar();
                startChronometro();

            }
        });
    }

    public void inicializarControles(){
        imagenes=new ImageButton[16];
        imagenes[0]=findViewById(R.id.button1);
        imagenes[1]=findViewById(R.id.button2);
        imagenes[2]=findViewById(R.id.button3);
        imagenes[3]=findViewById(R.id.button4);
        imagenes[4]=findViewById(R.id.button5);
        imagenes[5]=findViewById(R.id.button6);
        imagenes[6]=findViewById(R.id.button7);
        imagenes[7]=findViewById(R.id.button8);
        imagenes[8]=findViewById(R.id.button9);
        imagenes[9]=findViewById(R.id.button10);
        imagenes[10]=findViewById(R.id.button11);
        imagenes[11]=findViewById(R.id.button12);
        imagenes[12]=findViewById(R.id.button13);
        imagenes[13]=findViewById(R.id.button14);
        imagenes[14]=findViewById(R.id.button15);
        imagenes[15]=findViewById(R.id.button16);

        chronometro=findViewById(R.id.chronometro);

        btnMezclar=findViewById(R.id.btn_mezclar);
        btnSalir=findViewById(R.id.btn_salir);
        cmbTipo=findViewById(R.id.spn_tipos);
        cmbOpciones=findViewById(R.id.spn_opciones);
    }

    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int position, long id) {
        if(adapterView.getId()==R.id.spn_tipos){
            tipo=(int)cmbTipo.getSelectedItemId();
            switch(tipo){
                case 1:
                    juego = new Libre();
                    break;
                case 2:
                    juego = new Normal();
                    break;
            }
        }else if(adapterView.getId()==R.id.spn_opciones){
            img= (int)cmbOpciones.getSelectedItemId();
            cargarImagens(img);
        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {
    }

    private void cargarImagens(int img){
        switch (img){
            case 1://numeros
                imagenes[0].setBackgroundDrawable(getResources().getDrawable(R.drawable.n1));
                imagenes[1].setBackgroundDrawable(getResources().getDrawable(R.drawable.n2));
                imagenes[2].setBackgroundDrawable(getResources().getDrawable(R.drawable.n3));
                imagenes[3].setBackgroundDrawable(getResources().getDrawable(R.drawable.n4));
                imagenes[4].setBackgroundDrawable(getResources().getDrawable(R.drawable.n5));
                imagenes[5].setBackgroundDrawable(getResources().getDrawable(R.drawable.n6));
                imagenes[6].setBackgroundDrawable(getResources().getDrawable(R.drawable.n7));
                imagenes[7].setBackgroundDrawable(getResources().getDrawable(R.drawable.n8));
                imagenes[8].setBackgroundDrawable(getResources().getDrawable(R.drawable.n9));
                imagenes[9].setBackgroundDrawable(getResources().getDrawable(R.drawable.n10));
                imagenes[10].setBackgroundDrawable(getResources().getDrawable(R.drawable.n11));
                imagenes[11].setBackgroundDrawable(getResources().getDrawable(R.drawable.n12));
                imagenes[12].setBackgroundDrawable(getResources().getDrawable(R.drawable.n13));
                imagenes[13].setBackgroundDrawable(getResources().getDrawable(R.drawable.n14));
                imagenes[14].setBackgroundDrawable(getResources().getDrawable(R.drawable.n15));
                imagenes[15].setBackgroundDrawable(getResources().getDrawable(R.drawable.n16));
                resetChronometro();
                break;
            case 2://android
                imagenes[0].setBackgroundDrawable(getResources().getDrawable(R.drawable.a1));
                imagenes[1].setBackgroundDrawable(getResources().getDrawable(R.drawable.a2));
                imagenes[2].setBackgroundDrawable(getResources().getDrawable(R.drawable.a3));
                imagenes[3].setBackgroundDrawable(getResources().getDrawable(R.drawable.a4));
                imagenes[4].setBackgroundDrawable(getResources().getDrawable(R.drawable.a5));
                imagenes[5].setBackgroundDrawable(getResources().getDrawable(R.drawable.a6));
                imagenes[6].setBackgroundDrawable(getResources().getDrawable(R.drawable.a7));
                imagenes[7].setBackgroundDrawable(getResources().getDrawable(R.drawable.a8));
                imagenes[8].setBackgroundDrawable(getResources().getDrawable(R.drawable.a9));
                imagenes[9].setBackgroundDrawable(getResources().getDrawable(R.drawable.a10));
                imagenes[10].setBackgroundDrawable(getResources().getDrawable(R.drawable.a11));
                imagenes[11].setBackgroundDrawable(getResources().getDrawable(R.drawable.a12));
                imagenes[12].setBackgroundDrawable(getResources().getDrawable(R.drawable.a13));
                imagenes[13].setBackgroundDrawable(getResources().getDrawable(R.drawable.a14));
                imagenes[14].setBackgroundDrawable(getResources().getDrawable(R.drawable.a15));
                imagenes[15].setBackgroundDrawable(getResources().getDrawable(R.drawable.a16));
                resetChronometro();
                break;
            case 3://mario
                imagenes[0].setBackgroundDrawable(getResources().getDrawable(R.drawable.m1));
                imagenes[1].setBackgroundDrawable(getResources().getDrawable(R.drawable.m2));
                imagenes[2].setBackgroundDrawable(getResources().getDrawable(R.drawable.m3));
                imagenes[3].setBackgroundDrawable(getResources().getDrawable(R.drawable.m4));
                imagenes[4].setBackgroundDrawable(getResources().getDrawable(R.drawable.m5));
                imagenes[5].setBackgroundDrawable(getResources().getDrawable(R.drawable.m6));
                imagenes[6].setBackgroundDrawable(getResources().getDrawable(R.drawable.m7));
                imagenes[7].setBackgroundDrawable(getResources().getDrawable(R.drawable.m8));
                imagenes[8].setBackgroundDrawable(getResources().getDrawable(R.drawable.m9));
                imagenes[9].setBackgroundDrawable(getResources().getDrawable(R.drawable.m10));
                imagenes[10].setBackgroundDrawable(getResources().getDrawable(R.drawable.m11));
                imagenes[11].setBackgroundDrawable(getResources().getDrawable(R.drawable.m12));
                imagenes[12].setBackgroundDrawable(getResources().getDrawable(R.drawable.m13));
                imagenes[13].setBackgroundDrawable(getResources().getDrawable(R.drawable.m14));
                imagenes[14].setBackgroundDrawable(getResources().getDrawable(R.drawable.m15));
                imagenes[15].setBackgroundDrawable(getResources().getDrawable(R.drawable.m16));
                resetChronometro();
                break;
            case 4://Payaso
                imagenes[0].setBackgroundDrawable(getResources().getDrawable(R.drawable.p1));
                imagenes[1].setBackgroundDrawable(getResources().getDrawable(R.drawable.p2));
                imagenes[2].setBackgroundDrawable(getResources().getDrawable(R.drawable.p3));
                imagenes[3].setBackgroundDrawable(getResources().getDrawable(R.drawable.p4));
                imagenes[4].setBackgroundDrawable(getResources().getDrawable(R.drawable.p5));
                imagenes[5].setBackgroundDrawable(getResources().getDrawable(R.drawable.p6));
                imagenes[6].setBackgroundDrawable(getResources().getDrawable(R.drawable.p7));
                imagenes[7].setBackgroundDrawable(getResources().getDrawable(R.drawable.p8));
                imagenes[8].setBackgroundDrawable(getResources().getDrawable(R.drawable.p9));
                imagenes[9].setBackgroundDrawable(getResources().getDrawable(R.drawable.p10));
                imagenes[10].setBackgroundDrawable(getResources().getDrawable(R.drawable.p11));
                imagenes[11].setBackgroundDrawable(getResources().getDrawable(R.drawable.p12));
                imagenes[12].setBackgroundDrawable(getResources().getDrawable(R.drawable.p13));
                imagenes[13].setBackgroundDrawable(getResources().getDrawable(R.drawable.p14));
                imagenes[14].setBackgroundDrawable(getResources().getDrawable(R.drawable.p15));
                imagenes[15].setBackgroundDrawable(getResources().getDrawable(R.drawable.p16));
                resetChronometro();
                break;
            case 5://Sombrerero
                imagenes[0].setBackgroundDrawable(getResources().getDrawable(R.drawable.s1));
                imagenes[1].setBackgroundDrawable(getResources().getDrawable(R.drawable.s2));
                imagenes[2].setBackgroundDrawable(getResources().getDrawable(R.drawable.s3));
                imagenes[3].setBackgroundDrawable(getResources().getDrawable(R.drawable.s4));
                imagenes[4].setBackgroundDrawable(getResources().getDrawable(R.drawable.s5));
                imagenes[5].setBackgroundDrawable(getResources().getDrawable(R.drawable.s6));
                imagenes[6].setBackgroundDrawable(getResources().getDrawable(R.drawable.s7));
                imagenes[7].setBackgroundDrawable(getResources().getDrawable(R.drawable.s8));
                imagenes[8].setBackgroundDrawable(getResources().getDrawable(R.drawable.s9));
                imagenes[9].setBackgroundDrawable(getResources().getDrawable(R.drawable.s10));
                imagenes[10].setBackgroundDrawable(getResources().getDrawable(R.drawable.s11));
                imagenes[11].setBackgroundDrawable(getResources().getDrawable(R.drawable.s12));
                imagenes[12].setBackgroundDrawable(getResources().getDrawable(R.drawable.s13));
                imagenes[13].setBackgroundDrawable(getResources().getDrawable(R.drawable.s14));
                imagenes[14].setBackgroundDrawable(getResources().getDrawable(R.drawable.s15));
                imagenes[15].setBackgroundDrawable(getResources().getDrawable(R.drawable.s16));
                resetChronometro();
                break;
            case 6://Favorita
                imagenes[0].setBackgroundDrawable(getResources().getDrawable(R.drawable.f1));
                imagenes[1].setBackgroundDrawable(getResources().getDrawable(R.drawable.f2));
                imagenes[2].setBackgroundDrawable(getResources().getDrawable(R.drawable.f3));
                imagenes[3].setBackgroundDrawable(getResources().getDrawable(R.drawable.f4));
                imagenes[4].setBackgroundDrawable(getResources().getDrawable(R.drawable.f5));
                imagenes[5].setBackgroundDrawable(getResources().getDrawable(R.drawable.f6));
                imagenes[6].setBackgroundDrawable(getResources().getDrawable(R.drawable.f7));
                imagenes[7].setBackgroundDrawable(getResources().getDrawable(R.drawable.f8));
                imagenes[8].setBackgroundDrawable(getResources().getDrawable(R.drawable.f9));
                imagenes[9].setBackgroundDrawable(getResources().getDrawable(R.drawable.f10));
                imagenes[10].setBackgroundDrawable(getResources().getDrawable(R.drawable.f11));
                imagenes[11].setBackgroundDrawable(getResources().getDrawable(R.drawable.f12));
                imagenes[12].setBackgroundDrawable(getResources().getDrawable(R.drawable.f13));
                imagenes[13].setBackgroundDrawable(getResources().getDrawable(R.drawable.f14));
                imagenes[14].setBackgroundDrawable(getResources().getDrawable(R.drawable.f15));
                imagenes[15].setBackgroundDrawable(getResources().getDrawable(R.drawable.f16));
                resetChronometro();
                break;
        }
        if (tipo==2){
            imagenes[15].setBackgroundDrawable(getResources().getDrawable(R.drawable.vacio));
        }
    }

    private void mezclar(){
        int x;
        int y;
        Random r= new Random();
        for(int i=0;i<150;i++){
            x=r.nextInt(16);
            y=r.nextInt(16);
            if(juego.verificarMov(x)){
                switch(tipo){
                    case 1:
                        juego.moverPieza(x,y);
                        moverImagenes(x,y);
                        break;
                    case 2:
                        juego.moverPieza(x,dispo);
                        moverImagenes(x,dispo);
                        break;
                    case 3:
                        juego.moverPieza(x,y%4);
                        moverImagenes(x,y%4);
                        break;
                }
            }
        }

    }

    public void moverImagenes(int x, int y){
        ImageButton tempo=new  ImageButton(this);
        switch(tipo){
            case 2:
                dispo=x;
                tempo.setBackgroundDrawable(imagenes[x].getBackground());
                imagenes[x].setBackgroundDrawable(imagenes[y].getBackground());
                imagenes[y].setBackgroundDrawable(tempo.getBackground());
                break;
            case 1:
                tempo.setBackgroundDrawable(imagenes[x].getBackground());
                imagenes[x].setBackgroundDrawable(imagenes[y].getBackground());
                imagenes[y].setBackgroundDrawable(tempo.getBackground());
                break;
            case 3:
                break;
        }
    }

    @Override
    public boolean onTouch(View view, MotionEvent motionEvent) {
        switch(view.getId()){
            case R.id.button1:
                pos1=0;
                break;
            case R.id.button2:
                pos1=1;
                break;
            case R.id.button3:
                pos1=2;

                break;
            case R.id.button4:
                pos1=3;

                break;
            case R.id.button5:
                pos1=4;

                break;
            case R.id.button6:
                pos1=5;

                break;
            case R.id.button7:
                pos1=6;

                break;
            case R.id.button8:
                pos1=7;

                break;
            case R.id.button9:
                pos1=8;

                break;
            case R.id.button10:
                pos1=9;

                break;
            case R.id.button11:
                pos1=10;

                break;
            case R.id.button12:
                pos1=11;

                break;
            case R.id.button13:
                pos1=12;

                break;
            case R.id.button14:
                pos1=13;

                break;
            case R.id.button15:
                pos1=14;

                break;
            case R.id.button16:
                pos1=15;


                break;
        }
        switch(tipo){
            case 1:
                banPar=!banPar;
                if(!banPar){
                    pos2=pos1;
                }else{
                    juego.moverPieza(pos1,pos2);
                    moverImagenes(pos1,pos2);
                    if(juego.yaGano()){
                        Toast.makeText(getApplicationContext(),
                                "Has Ganado!",Toast.LENGTH_LONG).show();
                        stopChronometro();
                    }
                }
                break;
            case 2:
                if (juego.verificarMov(pos1)) {
                    juego.moverPieza(pos1, dispo);
                    moverImagenes(pos1, dispo);
                    contador++;
                    txtContador.setText(""+contador);
                    if (juego.yaGano()) {
                        Toast.makeText(getApplicationContext(),
                                "Has Ganado!", Toast.LENGTH_LONG).show();
                        stopChronometro();
                    }
                }
                break;
            case 3:
                if(motionEvent.getAction()==MotionEvent.ACTION_DOWN){
                    x1=(int)motionEvent.getX();
                    y1=(int)motionEvent.getY();
                }
                if(motionEvent.getAction()==MotionEvent.ACTION_UP){
                    x1=(int)motionEvent.getX();
                    y1=(int)motionEvent.getY();
                }
        }
        return false;
    }



    private void startChronometro() {
        if(!correr){
            chronometro.setBase(SystemClock.elapsedRealtime() - detenerse);
            chronometro.start();
            correr=true;
        }
    }

    private void stopChronometro() {
        if (correr){
            chronometro.stop();
            detenerse = SystemClock.elapsedRealtime() - chronometro.getBase();
            correr=false;
        }
    }

    private void resetChronometro() {
        chronometro.setBase(SystemClock.elapsedRealtime());
        detenerse=0;
    }


}/* End */